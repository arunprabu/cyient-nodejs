console.log("Directory name:" + __dirname); //the directory in while the file lies
console.log("File name:" + __filename); //name of the file with directory

console.log("Current Working Directory:" + process.cwd());